var searchData=
[
  ['qualitylevel_631',['qualityLevel',['../structktxAstcParams.html#a3d242e57e8f778ae8677bd337821589e',1,'ktxAstcParams::qualityLevel()'],['../structktxBasisParams.html#aac5068885c586a1454efbf2e9cf4b3ed',1,'ktxBasisParams::qualityLevel()']]],
  ['queue_632',['queue',['../structktxVulkanDeviceInfo.html#ab3246009ce333f50c2ca3d8187c3849e',1,'ktxVulkanDeviceInfo']]]
];
