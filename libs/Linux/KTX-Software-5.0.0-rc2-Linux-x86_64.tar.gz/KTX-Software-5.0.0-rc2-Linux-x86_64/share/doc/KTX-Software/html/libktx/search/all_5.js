var searchData=
[
  ['endpointrdothreshold_26',['endpointRDOThreshold',['../structktxBasisParams.html#aafccbc4e43845f62cf500d4792c7cf6a',1,'ktxBasisParams']]],
  ['etc1scompressionlevel_27',['etc1sCompressionLevel',['../structktxBasisParams.html#ac7ec144502a7f9b860bf4fdc070f95ac',1,'ktxBasisParams']]]
];
