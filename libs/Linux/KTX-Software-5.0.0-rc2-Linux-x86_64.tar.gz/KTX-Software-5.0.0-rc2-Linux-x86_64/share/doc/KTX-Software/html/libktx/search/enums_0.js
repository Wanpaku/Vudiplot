var searchData=
[
  ['ktx_5fbasis_5fcodec_5fe_692',['ktx_basis_codec_e',['../ktx_8h.html#afbe73b645e3720b5f1e9e58a2fe68e50',1,'ktx.h']]],
  ['ktx_5ferror_5fcode_5fe_693',['ktx_error_code_e',['../ktx_8h.html#a7780d97ec4de6aa30c4726fb71e3116c',1,'ktx.h']]],
  ['ktx_5fpack_5fastc_5fblock_5fdimension_5fe_694',['ktx_pack_astc_block_dimension_e',['../ktx_8h.html#a1873d492a1b1fc5fd3296192fce3e9d5',1,'ktx.h']]],
  ['ktx_5fpack_5fastc_5fencoder_5fmode_5fe_695',['ktx_pack_astc_encoder_mode_e',['../ktx_8h.html#ad9ebeed57afd9e14b6d857011cff38d6',1,'ktx.h']]],
  ['ktx_5fpack_5fastc_5fquality_5flevels_5fe_696',['ktx_pack_astc_quality_levels_e',['../ktx_8h.html#a8f70163f537a794c472479bc5c1905e9',1,'ktx.h']]],
  ['ktx_5fpack_5fuastc_5fflag_5fbits_5fe_697',['ktx_pack_uastc_flag_bits_e',['../ktx_8h.html#a9cb85e48ab10ea04747de7ef12087670',1,'ktx.h']]],
  ['ktx_5ftranscode_5fflag_5fbits_5fe_698',['ktx_transcode_flag_bits_e',['../ktx_8h.html#ab2288718afab080ff86e9d3250180fb6',1,'ktx.h']]],
  ['ktx_5ftranscode_5ffmt_5fe_699',['ktx_transcode_fmt_e',['../ktx_8h.html#a30cc58c576392303d9a5a54b57ef29b5',1,'ktx.h']]],
  ['ktxsupercmpscheme_700',['ktxSupercmpScheme',['../ktx_8h.html#a011cf6c6de4e1acd2307ec7d24ee5daa',1,'ktx.h']]],
  ['ktxtexturecreateflagbits_701',['ktxTextureCreateFlagBits',['../structktxTexture.html#ac184edbb9898b55efbbd80f635946545',1,'ktxTexture']]],
  ['ktxtexturecreatestorageenum_702',['ktxTextureCreateStorageEnum',['../structktxTexture.html#af0602c48f60fc85c4d59c1c58f624a2b',1,'ktxTexture']]]
];
