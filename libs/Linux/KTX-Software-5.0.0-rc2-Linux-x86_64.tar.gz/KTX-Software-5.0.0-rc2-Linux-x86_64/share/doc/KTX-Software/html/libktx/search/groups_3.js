var searchData=
[
  ['writer_838',['Writer',['../group__writer.html',1,'']]]
];
