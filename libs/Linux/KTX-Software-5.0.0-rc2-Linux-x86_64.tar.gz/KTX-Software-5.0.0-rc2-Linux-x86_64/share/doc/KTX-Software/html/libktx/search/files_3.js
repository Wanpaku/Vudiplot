var searchData=
[
  ['strings_2ec_433',['strings.c',['../strings_8c.html',1,'']]]
];
