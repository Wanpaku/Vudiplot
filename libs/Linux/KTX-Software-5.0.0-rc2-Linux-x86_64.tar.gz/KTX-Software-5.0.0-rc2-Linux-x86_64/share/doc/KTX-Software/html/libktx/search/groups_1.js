var searchData=
[
  ['reader_836',['Reader',['../group__reader.html',1,'']]]
];
