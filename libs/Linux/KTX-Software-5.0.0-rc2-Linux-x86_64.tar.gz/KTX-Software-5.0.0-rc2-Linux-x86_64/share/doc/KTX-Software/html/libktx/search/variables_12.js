var searchData=
[
  ['selectorrdothreshold_635',['selectorRDOThreshold',['../structktxBasisParams.html#aea4a4f651952b4831fdfc784f7058866',1,'ktxBasisParams']]],
  ['separatergtorgb_5fa_636',['separateRGToRGB_A',['../structktxBasisParams.html#a2b5e77802a353a04d6b8d1d848f98d47',1,'ktxBasisParams']]],
  ['setpos_637',['setpos',['../structktxStream.html#aba03500510363a0b45025645ba4327cf',1,'ktxStream']]],
  ['size_638',['size',['../structktxStream.html#ab3d4a868dd03d0fa92cdb5e5fd99ba50',1,'ktxStream']]],
  ['skip_639',['skip',['../structktxStream.html#ad224d1f8e4291a2e66e090b3c6df3698',1,'ktxStream']]],
  ['structsize_640',['structSize',['../structktxAstcParams.html#a51fe881fb2eae346ba017f7f55a1d642',1,'ktxAstcParams::structSize()'],['../structktxBasisParams.html#a51fe881fb2eae346ba017f7f55a1d642',1,'ktxBasisParams::structSize()']]]
];
