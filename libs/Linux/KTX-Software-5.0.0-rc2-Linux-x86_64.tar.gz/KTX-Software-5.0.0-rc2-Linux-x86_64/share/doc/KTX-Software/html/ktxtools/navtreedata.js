/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "KTX Tools Reference", "index.html", [
    [ "ktx", "ktx.html", [
      [ "ktx Overview", "index.html#autotoc_md0", null ],
      [ "SYNOPSIS", "ktx.html#ktx_synopsis", null ],
      [ "DESCRIPTION", "ktx.html#ktx_description", null ],
      [ "OPTIONS", "ktx.html#ktx_main_options", null ],
      [ "EXIT STATUS", "ktx.html#ktx_exitstatus", null ],
      [ "HISTORY", "ktx.html#ktx_history", null ],
      [ "AUTHOR", "ktx.html#ktx_author", null ]
    ] ],
    [ "ktx compare", "ktx_compare.html", [
      [ "SYNOPSIS", "ktx_compare.html#ktx_compare_synopsis", null ],
      [ "DESCRIPTION", "ktx_compare.html#ktx_compare_description", null ],
      [ "OPTIONS", "ktx_compare.html#ktx_compare_options", null ],
      [ "EXIT STATUS", "ktx_compare.html#ktx_compare_exitstatus", null ],
      [ "HISTORY", "ktx_compare.html#ktx_compare_history", null ],
      [ "AUTHOR", "ktx_compare.html#ktx_compare_author", null ]
    ] ],
    [ "ktx convert", "ktx_convert.html", [
      [ "SYNOPSIS", "ktx_convert.html#ktx_convert_synopsis", null ],
      [ "DESCRIPTION", "ktx_convert.html#ktx_convert_description", null ],
      [ "OPTIONS", "ktx_convert.html#ktx_convert_options", null ],
      [ "EXIT STATUS", "ktx_convert.html#ktx_convert_exitstatus", null ],
      [ "HISTORY", "ktx_convert.html#ktx_convert_history", null ],
      [ "AUTHOR", "ktx_convert.html#ktx_convert_author", null ]
    ] ],
    [ "ktx create", "ktx_create.html", [
      [ "SYNOPSIS", "ktx_create.html#ktx_create_synopsis", null ],
      [ "DESCRIPTION", "ktx_create.html#ktx_create_description", null ],
      [ "OPTIONS", "ktx_create.html#ktx_create_options", [
        [ "General Options", "ktx_create.html#ktx_create_options_general", null ],
        [ "Specific and Common Encoding Options", "ktx_create.html#ktx_create_options_encoding", null ]
      ] ],
      [ "TRANSFER FUNCTION HANDLING", "ktx_create.html#ktx_create_tf_handling", [
        [ "Details", "ktx_create.html#ktx_create_tf_handling_details", null ]
      ] ],
      [ "EXIT STATUS", "ktx_create.html#ktx_create_exitstatus", null ],
      [ "HISTORY", "ktx_create.html#ktx_create_history", null ],
      [ "AUTHOR", "ktx_create.html#ktx_create_author", null ]
    ] ],
    [ "ktx deflate", "ktx_deflate.html", [
      [ "SYNOPSIS", "ktx_deflate.html#ktx_deflate_synopsis", null ],
      [ "DESCRIPTION", "ktx_deflate.html#ktx_deflate_description", null ],
      [ "OPTIONS", "ktx_deflate.html#ktx_deflate_options", null ],
      [ "EXIT STATUS", "ktx_deflate.html#ktx_deflate_exitstatus", null ],
      [ "HISTORY", "ktx_deflate.html#ktx_deflate_history", null ],
      [ "AUTHOR", "ktx_deflate.html#ktx_deflate_author", null ]
    ] ],
    [ "ktx encode", "ktx_encode.html", [
      [ "SYNOPSIS", "ktx_encode.html#ktx_encode_synopsis", null ],
      [ "DESCRIPTION", "ktx_encode.html#ktx_encode_description", null ],
      [ "OPTIONS", "ktx_encode.html#ktx_encode_options", [
        [ "General Options", "ktx_encode.html#ktx_encode_options_general", null ],
        [ "Specific and Common Encoding Options", "ktx_encode.html#ktx_encode_options_encoding", null ]
      ] ],
      [ "EXIT STATUS", "ktx_encode.html#ktx_encode_exitstatus", null ],
      [ "HISTORY", "ktx_encode.html#ktx_encode_history", null ],
      [ "AUTHOR", "ktx_encode.html#ktx_encode_author", null ]
    ] ],
    [ "ktx extract", "ktx_extract.html", [
      [ "SYNOPSIS", "ktx_extract.html#ktx_extract_synopsis", null ],
      [ "DESCRIPTION", "ktx_extract.html#ktx_extract_description", null ],
      [ "OPTIONS", "ktx_extract.html#ktx_extract_options", null ],
      [ "EXIT STATUS", "ktx_extract.html#ktx_extract_exitstatus", null ],
      [ "HISTORY", "ktx_extract.html#ktx_extract_history", null ],
      [ "AUTHOR", "ktx_extract.html#ktx_extract_author", null ]
    ] ],
    [ "ktx help", "ktx_help.html", [
      [ "SYNOPSIS", "ktx_help.html#ktx_help_synopsis", null ],
      [ "DESCRIPTION", "ktx_help.html#ktx_help_description", null ],
      [ "OPTIONS", "ktx_help.html#ktx_help_options", null ],
      [ "EXIT STATUS", "ktx_help.html#ktx_help_exitstatus", null ],
      [ "HISTORY", "ktx_help.html#ktx_help_history", null ],
      [ "AUTHOR", "ktx_help.html#ktx_help_author", null ]
    ] ],
    [ "ktx info", "ktx_info.html", [
      [ "SYNOPSIS", "ktx_info.html#ktx_info_synopsis", null ],
      [ "DESCRIPTION", "ktx_info.html#ktx_info_description", null ],
      [ "OPTIONS", "ktx_info.html#ktx_info_options", null ],
      [ "EXIT STATUS", "ktx_info.html#ktx_info_exitstatus", null ],
      [ "HISTORY", "ktx_info.html#ktx_info_history", null ],
      [ "AUTHOR", "ktx_info.html#ktx_info_author", null ]
    ] ],
    [ "ktx transcode", "ktx_transcode.html", [
      [ "SYNOPSIS", "ktx_transcode.html#ktx_transcode_synopsis", null ],
      [ "DESCRIPTION", "ktx_transcode.html#ktx_transcode_description", null ],
      [ "OPTIONS", "ktx_transcode.html#ktx_transcode_options", null ],
      [ "EXIT STATUS", "ktx_transcode.html#ktx_transcode_exitstatus", null ],
      [ "HISTORY", "ktx_transcode.html#ktx_transcode_history", null ],
      [ "AUTHOR", "ktx_transcode.html#ktx_transcode_author", null ]
    ] ],
    [ "ktx validate", "ktx_validate.html", [
      [ "SYNOPSIS", "ktx_validate.html#ktx_validate_synopsis", null ],
      [ "DESCRIPTION", "ktx_validate.html#ktx_validate_description", null ],
      [ "OPTIONS", "ktx_validate.html#ktx_validate_options", null ],
      [ "EXIT STATUS", "ktx_validate.html#ktx_validate_exitstatus", null ],
      [ "HISTORY", "ktx_validate.html#ktx_validate_history", null ],
      [ "AUTHOR", "ktx_validate.html#ktx_validate_author", null ]
    ] ],
    [ "Package", "../index.html", null ],
    [ "libktx Reference", "../libktx/index.html", null ],
    [ "KTX Javascript Wrappers Reference", "../ktxjswrappers/index.html", null ],
    [ "pyktx Reference", "../pyktx/index.html", null ],
    [ "License", "../license.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"../index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';