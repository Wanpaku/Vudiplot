var searchData=
[
  ['classid_572',['classId',['../structktxTexture.html#ac838c216df52582085ca9e1eb6d19d07',1,'ktxTexture']]],
  ['closeondestruct_573',['closeOnDestruct',['../structktxStream.html#abac8ddd51b8b30aee6c98a1ab2adef13',1,'ktxStream']]],
  ['cmdbuffer_574',['cmdBuffer',['../structktxVulkanDeviceInfo.html#a8d2064b68f606e62edad9d1a8dcab4ca',1,'ktxVulkanDeviceInfo']]],
  ['cmdpool_575',['cmdPool',['../structktxVulkanDeviceInfo.html#ab3f05272e12842d5d4d29fca7baa2e50',1,'ktxVulkanDeviceInfo']]],
  ['codec_576',['codec',['../structktxBasisParams.html#adcc997cb15a8a35f34be3b5d11eb404c',1,'ktxBasisParams']]],
  ['custom_5fptr_577',['custom_ptr',['../structktxStream.html#ae56af1d8b462013a1650963a8d007a0d',1,'ktxStream']]]
];
