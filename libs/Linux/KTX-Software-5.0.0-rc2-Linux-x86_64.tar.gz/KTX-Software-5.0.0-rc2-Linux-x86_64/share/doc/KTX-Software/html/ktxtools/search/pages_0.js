var searchData=
[
  ['authors_13',['Authors',['../../authors.html',1,'']]]
];
